mpirun -np 1 --map-by ppr:2:node:pe=4 /org/abacus-group/abacususer01/abacus_hse_gpu_experiment/runs/lcao-hse/ddla-vbatched2s-validation-20261024/build-libri-tests/real_float
