/org/abacus-group/abacususer01/abacus_hse_gpu_experiment/runs/lcao-hse/ddla-vbatched2s-validation-20261024/abacus-build/abacus_std_gpu --version
