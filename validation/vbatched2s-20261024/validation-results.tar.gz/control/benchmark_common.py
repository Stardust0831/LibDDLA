#!/usr/bin/env python3
"""Paired HSE timings using one binary and explicit exx_device selection."""
import argparse
import csv
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import re
import subprocess
import threading
import time


def structure(material):
    if material == 'water24':
        species = [('H', 1.008, 'H_ONCV_PBE-1.0.upf', 'H_gga_6au_60Ry_2s1p.orb'),
                   ('O', 15.999, 'O_ONCV_PBE-1.0.upf', 'O_gga_6au_60Ry_2s2p1d.orb')]
        cell = [9.0, 9.0, 9.0]
        positions = {'H': [], 'O': []}
        for n, center in enumerate(itertools.product((2.25, 6.75), repeat=3)):
            angle = 0.37 * n
            positions['O'].append(center)
            for x, y, z in ((0.985, 0., 0.), (-0.25, 0.951, 0.015)):
                positions['H'].append((center[0] + x * math.cos(angle) - y * math.sin(angle),
                                       center[1] + x * math.sin(angle) + y * math.cos(angle),
                                       center[2] + z))
        cutoff, bands = 60, 40
    elif material in ('si32', 'si64', 'si128', 'si8'):
        species = [('Si', 28.0855, 'Si_dojo_nsoc.upf', 'Si_dojo_6au.orb')]
        a = 5.43
        nx, ny, nz = {'si8': (1, 1, 1), 'si32': (2, 2, 1), 'si64': (2, 2, 2), 'si128': (2, 2, 4)}[material]
        cell = [nx*a, ny*a, nz*a]
        basis = [(0, 0, 0), (0, .5, .5), (.5, 0, .5), (.5, .5, 0),
                 (.25, .25, .25), (.25, .75, .75), (.75, .25, .75), (.75, .75, .25)]
        positions = {'Si': [((x+i)*a, (y+j)*a, (z+k)*a) for i in range(nx)
                            for j in range(ny) for k in range(nz) for x, y, z in basis]}
        cutoff, bands = 60, 20*nx*ny*nz
    elif material == 'cspbi3_20':
        species = [('Cs', 132.905, 'Cs_ONCV_PBE_FR-1.0.upf', 'Cs_gga_10au_100Ry_4s2p1d.orb'),
                   ('Pb', 207.2, 'Pb_ONCV_PBE-1.0.upf', 'Pb_gga_7au_100Ry_2s2p2d1f.orb'),
                   ('I', 126.904, 'I_ONCV_PBE_FR-1.1.upf', 'I_gga_7au_100Ry_2s2p2d1f.orb')]
        a = 6.3
        cell = [2*a, 2*a, a]
        basis = {'Cs': [(0, 0, 0)], 'Pb': [(.5, .5, .5)],
                 'I': [(.5, .5, 0), (.5, 0, .5), (0, .5, .5)]}
        positions = {element: [((x+i)*a, (y+j)*a, z*a) for i in range(2)
                               for j in range(2) for x, y, z in points]
                     for element, points in basis.items()}
        cutoff, bands = 100, 180
    else:
        raise ValueError(material)
    # Break perfect crystal symmetry so force agreement is nontrivial.
    if material != 'water24':
        n = 0
        for element in positions:
            displaced = []
            for p in positions[element]:
                displaced.append(tuple((p[d] + 0.025 * math.sin((n+1)*(d+1)*1.7)) % cell[d]
                                       for d in range(3)))
                n += 1
            positions[element] = displaced
    text = 'ATOMIC_SPECIES\n'
    text += ''.join('{} {} {}\n'.format(*s[:3]) for s in species)
    text += '\nNUMERICAL_ORBITAL\n' + '\n'.join(s[3] for s in species)
    text += '\n\nLATTICE_CONSTANT\n1.8897261254578281\n\nLATTICE_VECTORS\n'
    text += '{} 0 0\n0 {} 0\n0 0 {}\n\nATOMIC_POSITIONS\nCartesian\n'.format(*cell)
    for element, _, _, _ in species:
        text += '\n{}\n0\n{}\n'.format(element, len(positions[element]))
        text += ''.join('{:.12f} {:.12f} {:.12f} 1 1 1\n'.format(*p) for p in positions[element])
    return text, species, cutoff, bands, sum(map(len, positions.values()))


def write_inputs(work, source, material, mode, backend):
    work.mkdir(parents=True)
    stru, species, cutoff, bands, atoms = structure(material)
    (work/'STRU').write_text(stru)
    (work/'KPT').write_text('K_POINTS\n0\nGamma\n1 1 1 0 0 0\n')
    values = dict(suffix='bench', calculation='scf', basis_type='lcao', device='gpu',
                  ks_solver='cusolver', device_exx=backend, gamma_only=1, nspin=1,
                  ntype=len(species), nbands=bands, symmetry=0, exx_symmetry_realspace=0,
                  pseudo_dir=str(source/'tests/PP_ORB'), orbital_dir=str(source/'tests/PP_ORB'),
                  ecutwfc=cutoff, scf_thr='1e-9', scf_ene_thr='1e-8', scf_nmax=200,
                  smearing_method='gaussian', smearing_sigma=0.002,
                  mixing_type='broyden', mixing_beta=0.2, dft_functional='hse',
                  exx_real_number=1, exx_pca_threshold='1e-4', exx_ccp_rmesh_times=1,
                  exx_separate_loop=1, exx_hybrid_step=50, cal_force=int(mode=='forces'),
                  cal_stress=0)
    (work/'INPUT').write_text('INPUT_PARAMETERS\n'+''.join('{} {}\n'.format(k,v) for k,v in values.items()))
    assets = {name: hashlib.sha256((source/'tests/PP_ORB'/name).read_bytes()).hexdigest()
              for s in species for name in s[2:]}
    (work/'input-assets.json').write_text(json.dumps(assets, indent=2)+'\n')
    return atoms


def gpu_monitor(work, stop, samples):
    with (work/'gpu-memory.csv').open('w') as stream:
        writer = csv.writer(stream)
        writer.writerow(['time', 'pid', 'uuid', 'mib'])
        while not stop.is_set():
            result = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid,used_gpu_memory',
                                     '--format=csv,noheader,nounits'], capture_output=True, text=True)
            for line in result.stdout.splitlines():
                fields = [x.strip() for x in line.split(',')]
                if len(fields)!=3 or not fields[0].isdigit() or not fields[2].isdigit():
                    continue
                try:
                    if Path('/proc/'+fields[0]+'/cwd').resolve()!=work:
                        continue
                except OSError:
                    continue
                row = [time.time(), int(fields[0]), fields[1], int(fields[2])]
                samples.append(row)
                maps = Path('/proc/' + fields[0] + '/maps')
                try:
                    paths = sorted({line.split()[-1] for line in maps.read_text().splitlines()
                                    if 'libddla.so' in line})
                    if paths:
                        (work / ('ddla-loaded-' + fields[0] + '.json')).write_text(json.dumps(paths) + '\n')
                except OSError:
                    pass
                writer.writerow(row)
            stream.flush()
            stop.wait(0.5)


def run_case(binary, work, atoms, mode, timeout):
    samples = []
    stop = threading.Event()
    monitor = threading.Thread(target=gpu_monitor, args=(work,stop,samples), daemon=True)
    monitor.start()
    start = time.monotonic()
    try:
        with (work/'stdout.log').open('w') as stdout:
            process = subprocess.run(['timeout', '--kill-after=30s', str(timeout)+'s',
                                      'mpirun', '-np', os.environ['BENCH_RANKS'], '--bind-to', 'none',
                                      'python3', str(Path(__file__).with_name('rank_launcher.py')), str(binary)],
                                     cwd=work, stdout=stdout, stderr=subprocess.STDOUT)
        elapsed = time.monotonic()-start
    finally:
        stop.set()
        monitor.join(timeout=10)
    if process.returncode:
        raise RuntimeError('{} exited {}'.format(work,process.returncode))
    stdout = (work/'stdout.log').read_text()
    log = (work/'OUT.bench/running_scf.log').read_text()
    energies = re.findall(r'!FINAL_ETOT_IS\s+([-+\d.eE]+)',log)
    deltas = [float(x) for x in re.findall(r'deltaE \(eV\) from outer loop:\s*([-+\d.eE]+)',stdout)]
    if not energies or '#SCF IS CONVERGED#' not in log or not deltas or abs(deltas[-1])>=1e-8 or len(deltas)>=50:
        raise RuntimeError('SCF/EXX convergence not established: '+str(work))
    timing = {cls+'.'+fn: {'seconds':float(seconds), 'calls':int(calls)}
              for cls,fn,seconds,calls in re.findall(r'^\s*(\S+)\s+(\S+)\s+([\d.]+)\s+(\d+)\s+[\d.]+\s+[\d.]+',stdout,re.M)}
    forces = []
    if mode=='forces':
        block=log.rsplit('#TOTAL-FORCE (eV/Angstrom)#',1)[-1]
        rows=re.findall(r'^\s*[A-Z][a-z]?\d+\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s*$',block,re.M)
        if len(rows)!=atoms:
            raise RuntimeError('Incomplete forces: '+str(work))
        forces=[float(x) for row in rows for x in row]
    bases=re.findall(r'TOTAL NBASE\s+(\d+)',stdout)
    return dict(wall_seconds=elapsed, energy_ev=float(energies[-1]), force_ev_angstrom=forces,
                outer_steps=len(deltas), outer_delta_ev=deltas[-1],
                inner_steps=len(re.findall(r'^\s*[A-Z]+\d+\s+[-+\d]',stdout,re.M)),timing=timing,
                basis_functions=int(bases[-1]) if bases else None,
                gpu_peak_process_mib=max((x[3] for x in samples),default=None))

