import json
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent.parent
records = []
checks = []
for group in ['benchmark', 'benchmark-si64-force', 'benchmark-cspbi3', 'benchmark-si8-si128']:
    benchmark = root / 'results' / group
    group_records = json.loads((benchmark / 'measurements.json').read_text())
    for row in group_records:
        row['result_group'] = group
    records.extend(group_records)
    checks.extend(json.loads((benchmark / 'comparisons.json').read_text()))
    if group != 'benchmark':
        assert (benchmark / 'PASS').exists(), group
assert len(records) == 39 and len(checks) == 27, (len(records), len(checks))
assert all(check['passed'] for check in checks)
(root / 'results/all-measurements.json').write_text(json.dumps(records, indent=2) + '\n')
(root / 'results/all-comparisons.json').write_text(json.dumps(checks, indent=2) + '\n')
summary = []
keys = list(dict.fromkeys((row['material'], row['mode'], row['ranks']) for row in records))
timers = ['Exx_LRI.cal_exx_elec', 'Exx_LRI.cal_exx_force', 'ESolver_KS_LCAO.cal_force']
for material, mode, ranks in keys:
    group = [r for r in records if (r['material'], r['mode'], r['ranks']) == (material, mode, ranks)
             and r['backend'] == 'gpu']
    variants = {v: [r for r in group if r['variant'] == v] for v in ['baseline', 'candidate']}
    assert all(len(rows) == 3 for rows in variants.values())
    wall = {v: [r['wall_seconds'] for r in rows] for v, rows in variants.items()}
    medians = {v: statistics.median(values) for v, values in wall.items()}
    selected = {}
    for timer in timers:
        if all(timer in r['timing'] for r in group):
            samples = {v: [r['timing'][timer]['seconds'] for r in rows] for v, rows in variants.items()}
            med = {v: statistics.median(values) for v, values in samples.items()}
            selected[timer] = {'samples': samples, 'medians': med,
                               'speedup': med['baseline'] / med['candidate']}
    summary.append({'material': material, 'mode': mode, 'gpus': ranks,
                    'wall_samples': wall, 'wall_medians': medians,
                    'wall_speedup': medians['baseline'] / medians['candidate'],
                    'wall_time_reduction_percent': 100 * (1 - medians['candidate'] / medians['baseline']),
                    'timers': selected,
                    'peak_memory_mib': {v: [r['gpu_peak_process_mib'] for r in rows] for v, rows in variants.items()},
                    'scf_steps': {v: [[r['outer_steps'], r['inner_steps']] for r in rows] for v, rows in variants.items()}})

numeric = {}
for kind in ['gpu', 'cpu']:
    subset = [c for c in checks if ('-cpu-' in c['reference']) == (kind == 'cpu')]
    numeric[kind] = {'comparisons': len(subset),
                     'maximum_deltas': {key: max(c['delta'][key] for c in subset) for key in subset[0]['delta']},
                     'all_scf_steps_equal': all(c['same_scf_steps'] for c in subset)}
result = {'cases': summary, 'numerical': numeric, 'passed': True}
(root / 'results/summary.json').write_text(json.dumps(result, indent=2) + '\n')
lines = ['| HSE case | GPUs | Baseline median (s) | Candidate median (s) | Wall speedup |',
         '|---|---:|---:|---:|---:|']
for row in summary:
    med = row['wall_medians']
    lines.append(f"| {row['material']} {row['mode']} | {row['gpus']} | {med['baseline']:.3f} | {med['candidate']:.3f} | {row['wall_speedup']:.3f}× |")
(root / 'results/table.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
print(json.dumps(numeric, indent=2))
