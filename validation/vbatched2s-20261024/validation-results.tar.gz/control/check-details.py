import os
from pathlib import Path
import subprocess
root = Path(os.environ['VALIDATION_ROOT'])
original_library_path = os.environ['LD_LIBRARY_PATH']
regression = root / 'results/final-gemm-regression'
if not (regression / 'PASS').exists():
    regression.mkdir(exist_ok=True)
    with (regression / 'build.log').open('wb') as log:
        subprocess.run(['cmake', '--build', str(root / 'build-candidate'), '--target',
                        'test_gemm_vbatched', '--parallel', '12'], stdout=log, stderr=subprocess.STDOUT, check=True)
    for variant in ['baseline', 'candidate']:
        env = {**os.environ, 'LD_LIBRARY_PATH': f'{root}/install-{variant}/lib:' + original_library_path}
        for ranks in [1, 2]:
            with (regression / f'{variant}-mpi{ranks}.log').open('wb') as log:
                subprocess.run(['mpirun', '-np', str(ranks), '--bind-to', 'none',
                                str(root / 'build-candidate/tests/test_gemm_vbatched')],
                               env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
    (regression / 'PASS').touch()

profile = root / 'results/profile'
if not (profile / 'DONE').exists():
    profile.mkdir(exist_ok=True)
    nsys = '/opt/devtools/nvidia/hpc_sdk/Linux_x86_64/25.7/profilers/Nsight_Systems/bin/nsys'
    for variant in ['baseline', 'candidate']:
        env = {**os.environ, 'LD_LIBRARY_PATH': f'{root}/install-{variant}/lib:' + original_library_path}
        with (profile / f'{variant}.log').open('wb') as log:
            p = subprocess.run(['mpirun', '-np', '1', '--bind-to', 'none', nsys, 'profile',
                                '--trace=cuda', '--sample=none', '--cpuctxsw=none', '--force-overwrite=true',
                                '-o', str(profile / variant), str(root / 'benchmark_vbatched2s'), '100'],
                               env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120)
        if p.returncode == 0:
            with (profile / f'{variant}-stats.log').open('wb') as log:
                subprocess.run([nsys, 'stats', '--report', 'cuda_api_sum,cuda_gpu_kern_sum', '--format', 'csv',
                                '--output', str(profile / (variant + '-summary')), str(profile / (variant + '.nsys-rep'))],
                               stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
        else:
            print('Profiler unavailable; inspect', profile / f'{variant}.log', flush=True)
    (profile / 'DONE').touch()


