import json
import os
from pathlib import Path
import shutil
import subprocess

import benchmark_common as common

root = Path(os.environ['VALIDATION_ROOT'])
out = root / 'results/hse-profile'
out.mkdir(exist_ok=True)
nsys = '/opt/devtools/nvidia/hpc_sdk/Linux_x86_64/25.7/profilers/Nsight_Systems/bin/nsys'
binary = root / 'abacus-build/abacus_std_gpu'
template = root / 'results/benchmark-si8-si128/si8-forces-2gpu-baseline-gpu-0'
groups = {}
for cpu in sorted(os.sched_getaffinity(0)):
    topology = Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
    key = tuple(int((topology / name).read_text()) for name in ['physical_package_id', 'core_id'])
    groups.setdefault(key, []).append(cpu)
cores = [groups[key][0] for key in sorted(groups)]
assert len(cores) >= 8
original_path = os.environ['LD_LIBRARY_PATH']
os.environ.update(OMP_NUM_THREADS='4', OMP_THREAD_LIMIT='4', OMP_DYNAMIC='FALSE',
                  OMP_MAX_ACTIVE_LEVELS='1', OMP_PROC_BIND='close', BENCH_RANKS='2')
for variant in ['baseline', 'candidate']:
    work = out / variant
    work.mkdir()
    for name in ['INPUT', 'STRU', 'KPT']:
        shutil.copy2(template / name, work / name)
    (work / 'mapping.json').write_text(json.dumps({'allocated_cpus': sorted(os.sched_getaffinity(0)),
                                                  'rank_cpus': [cores[:4], cores[4:8]]}) + '\n')
    os.environ['BENCH_MAPPING_FILE'] = str(work / 'mapping.json')
    os.environ['LD_LIBRARY_PATH'] = str(root / f'install-{variant}/lib') + ':' + original_path
    wrapper = work / 'profile.sh'
    wrapper.write_text('#!/usr/bin/env bash\nexec ' + nsys + ' profile --trace=cuda --sample=none --cpuctxsw=none '
                       '--force-overwrite=true -o "' + str(work / 'rank-') + '${OMPI_COMM_WORLD_RANK}" '
                       + str(binary) + '\n')
    wrapper.chmod(0o755)
    print('PROFILE', variant, flush=True)
    # Profiled elapsed times are separate from the performance measurements.
    record = common.run_case(wrapper, work, 8, 'forces', 900)
    (work / 'validation.json').write_text(json.dumps(record, indent=2) + '\n')
    for rank in [0, 1]:
        prefix = work / f'rank-{rank}'
        with (work / f'stats-{rank}.log').open('wb') as log:
            subprocess.run([nsys, 'stats', '--report', 'cuda_api_sum,cuda_gpu_kern_sum', '--format', 'csv',
                            '--output', str(prefix) + '-summary', str(prefix) + '.nsys-rep'],
                           stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
(out / 'PASS').touch()
