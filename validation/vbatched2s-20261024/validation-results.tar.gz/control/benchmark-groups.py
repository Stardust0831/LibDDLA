import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys

import benchmark_common as common

root = Path(os.environ['VALIDATION_ROOT'])
out = root / ('results/benchmark-' + os.environ['BENCH_GROUP'])
out.mkdir(parents=True, exist_ok=True)
source = root / 'abacus-source'
binary = root / 'abacus-build/abacus_std_gpu'
allocated = sorted(os.sched_getaffinity(0))
groups = {}
for cpu in allocated:
    topology = Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
    key = tuple(int((topology / name).read_text()) for name in ('physical_package_id', 'core_id'))
    groups.setdefault(key, []).append(cpu)
cores = [groups[key][0] for key in sorted(groups)]
devices = os.environ['CUDA_VISIBLE_DEVICES'].split(',')
assert len(cores) >= 4 * len(devices), (cores, devices)
original_library_path = os.environ['LD_LIBRARY_PATH']
os.environ.update(OMP_DYNAMIC='FALSE', OMP_MAX_ACTIVE_LEVELS='1', OMP_PROC_BIND='close',
                  OMP_NUM_THREADS='4', OMP_THREAD_LIMIT='4', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
records = []
checks = []


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


save(out / ('environment-' + os.environ['SLURM_JOB_ID'] + '.json'), {
    'job_id': os.environ['SLURM_JOB_ID'], 'node': os.uname().nodename,
    'allocated_cpus': allocated, 'physical_cores': cores, 'devices': devices,
    'abacus_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'threads_per_rank': 4, 'blas_threads': 1,
})


def run(material, mode, ranks, variant, repetition, backend='gpu'):
    name = f'{material}-{mode}-{ranks}gpu-{variant}-{backend}-{repetition}'
    work = out / name
    if (work / 'result.json').exists():
        record = json.loads((work / 'result.json').read_text())
        records.append(record)
        return record
    assert not work.exists(), ('incomplete run requires inspection', work)
    atoms = common.write_inputs(work, source, material, mode, backend)
    os.environ['BENCH_RANKS'] = str(ranks)
    os.environ['CUDA_VISIBLE_DEVICES'] = ','.join(devices[:ranks])
    os.environ['BENCH_MAPPING_FILE'] = str(work / 'mapping.json')
    save(work / 'mapping.json', {'allocated_cpus': allocated,
                               'rank_cpus': [cores[r*4:(r+1)*4] for r in range(ranks)]})
    text = (work / 'INPUT').read_text() + '\nkpar 1\n'
    if material == 'si8':
        text = text.replace('gamma_only 1', 'gamma_only 0').replace('exx_real_number 1', 'exx_real_number 0')
        text = text.replace('cal_stress 0', 'cal_stress 1')
        (work / 'KPT').write_text('K_POINTS\n0\nGamma\n2 2 2 0 0 0\n')
    (work / 'INPUT').write_text(text)
    library_dir = root / f'install-{variant}/lib'
    os.environ['LD_LIBRARY_PATH'] = str(library_dir) + ':' + original_library_path
    ldd = subprocess.check_output(['ldd', str(binary)], text=True)
    (work / 'ldd.txt').write_text(ldd)
    selected = [line.strip() for line in ldd.splitlines() if 'libddla.so' in line]
    assert len(selected) == 1 and str(library_dir) in selected[0], selected
    print('START', name, flush=True)
    record = dict(material=material, mode=mode, ranks=ranks, variant=variant,
                  repetition=repetition, backend=backend, atoms=atoms, directory=name,
                  **common.run_case(binary, work, atoms, mode, 1800))
    for path in work.glob('ddla-loaded-*.json'):
        mapped = json.loads(path.read_text())
        assert all(str(library_dir) in entry for entry in mapped), mapped
    log = (work / 'OUT.bench/running_scf.log').read_text()
    assert '#SCF IS NOT CONVERGED#' not in log
    info = (work / 'OUT.bench/INPUT.info').read_text()
    assert re.search(r'^\s*device_exx\s+' + backend + r'\s', info, re.M), name
    stress = []
    if material == 'si8':
        section = log.split('#TOTAL-STRESS (kbar)#')[-1].split('#TOTAL-PRESSURE')[0]
        rows = re.findall(r'^\s*([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s*$', section, re.M)
        assert len(rows) == 3, (name, rows)
        stress = [float(v) for row in rows for v in row]
    record['stress_kbar'] = stress
    assert all(math.isfinite(v) for v in [record['energy_ev'], *record['force_ev_angstrom'], *stress])
    assert record['inner_steps'] > 0
    save(work / 'result.json', record)
    records.append(record)
    save(out / 'measurements.json', records)
    print('END', name, 'wall=', round(record['wall_seconds'], 3),
          'outer=', record['outer_steps'], 'inner=', record['inner_steps'], flush=True)
    return record


def compare(reference, candidate, cpu=False):
    delta = {'energy_ev_per_atom': abs(reference['energy_ev'] - candidate['energy_ev']) / candidate['atoms']}
    for key in ['force_ev_angstrom', 'stress_kbar']:
        assert len(reference[key]) == len(candidate[key])
        delta[key] = max((abs(a-b) for a, b in zip(reference[key], candidate[key])), default=0)
    tolerances = {'energy_ev_per_atom': 1e-6 if cpu else 1e-8,
                  'force_ev_angstrom': 1e-4 if cpu else 1e-6,
                  'stress_kbar': 1e-3 if cpu else 1e-4}
    check = {'reference': reference['directory'], 'candidate': candidate['directory'],
             'delta': delta, 'tolerances': tolerances,
             'same_scf_steps': all(reference[k] == candidate[k] for k in ['inner_steps', 'outer_steps']),
             'passed': all(delta[k] <= tolerances[k] for k in delta)}
    checks.append(check)
    save(out / 'comparisons.json', checks)
    assert check['passed'], check


cases = [('si64', 'single_point', 1), ('si64', 'forces', 1),
         ('cspbi3_20', 'single_point', 2), ('cspbi3_20', 'forces', 2),
         ('si8', 'forces', 2), ('si128', 'forces', 2)]
if len(sys.argv) > 1:
    cases = [case for case in cases if case[0] in sys.argv[1:] or (case[0] + ':' + case[1]) in sys.argv[1:]]
for material, mode, ranks in cases:
    candidates = []
    for repetition in range(3):
        pair = {}
        order = ['baseline', 'candidate'] if repetition % 2 == 0 else ['candidate', 'baseline']
        for variant in order:
            pair[variant] = run(material, mode, ranks, variant, repetition)
        compare(pair['baseline'], pair['candidate'])
        candidates.append(pair['candidate'])
    if mode == 'forces' and material != 'si128':
        reference = run(material, mode, ranks, 'baseline', 0, backend='cpu')
        for candidate in candidates:
            compare(reference, candidate, cpu=True)
save(out / 'measurements.json', records)
save(out / 'comparisons.json', checks)
(out / 'PASS').touch()
print('ALL HSE COMPARISONS PASSED', flush=True)
