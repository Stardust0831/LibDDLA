"""Archive completed validation logs and inputs, excluding restart/binary output."""
from pathlib import Path
import hashlib
import json
import sys
import tarfile

root = Path(sys.argv[1]).resolve()
groups = {'benchmark': 6, 'benchmark-si64-force': 7,
          'benchmark-cspbi3': 13, 'benchmark-si8-si128': 13}
files = set()
for group, count in groups.items():
    directory = root / 'results' / group
    records = json.loads((directory / 'measurements.json').read_text())
    assert len(records) == count, (group, len(records))
    if group != 'benchmark':
        assert (directory / 'PASS').exists(), group
    for name in ['measurements.json', 'comparisons.json', 'PASS']:
        if (directory / name).exists(): files.add(directory / name)
    files.update(directory.glob('environment-*.json'))
    for record in records:
        work = directory / record['directory']
        for pattern in ['INPUT', 'STRU', 'KPT', 'input-assets.json', 'mapping.json', 'binding-*.json',
                        'ddla-loaded-*.json', 'result.json', 'ldd.txt', 'stdout.log', 'gpu-memory.csv',
                        'OUT.bench/running_scf.log', 'OUT.bench/INPUT.info', 'OUT.bench/warning.log']:
            files.update(work.glob(pattern))
for group in ['configuration-attempt-1924079', 'build', 'integration-build',
              'final-gemm-regression-v2', 'microbenchmark', 'profile']:
    files.update(p for p in (root / 'results' / group).glob('*') if p.is_file() and p.suffix not in ['.sqlite', '.nsys-rep'])
failed = root / 'results/failed-cpu-reference-30GiB'
for name in ['INPUT', 'STRU', 'KPT', 'stdout.log', 'OUT.bench/running_scf.log', 'OUT.bench/warning.log']:
    if (failed / name).exists(): files.add(failed / name)
for pattern in ['*-*.log', 'control/*.py', 'control/*.sbatch', 'control/*.cpp', 'control/CMakeLists.txt', 'control/modules.sh']:
    files.update(root.glob(pattern))
profile = root / 'results/hse-profile'
if (profile / 'PASS').exists():
    files.add(profile / 'PASS')
    for variant in ['baseline', 'candidate']:
        for pattern in ['*.csv', '*.json', '*.log', 'INPUT', 'STRU', 'KPT', 'OUT.bench/running_scf.log']:
            files.update((profile / variant).glob(pattern))
hashes = {}
for name in ['install-baseline/lib/libddla.so.0.0.5', 'install-candidate/lib/libddla.so.0.0.5',
             'ddla-candidate/src/BLAS/gemm_vbatched.cpp', 'ddla-candidate/tests/test_gemm_vbatched.cpp',
             'abacus-build/abacus_std_gpu']:
    hashes[name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
identity = root / 'results/tested-file-sha256.json'
identity.write_text(json.dumps(hashes, indent=2) + '\n')
files.add(identity)
with tarfile.open(root / 'validation-results.tar.gz', 'w:gz') as archive:
    for path in sorted(files):
        archive.add(path, arcname=str(path.relative_to(root)), recursive=False)
print('Archived', len(files), 'files;', (root / 'validation-results.tar.gz').stat().st_size, 'bytes')
