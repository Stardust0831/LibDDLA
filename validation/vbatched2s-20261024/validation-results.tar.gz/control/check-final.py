import os
from pathlib import Path
import subprocess
root = Path(os.environ['VALIDATION_ROOT'])
original_library_path = os.environ['LD_LIBRARY_PATH']
regression = root / 'results/final-gemm-regression-v2'
if not (regression / 'PASS').exists():
    regression.mkdir(exist_ok=True)
    with (regression / 'build.log').open('wb') as log:
        subprocess.run(['cmake', '--build', str(root / 'build-candidate'), '--target',
                        'test_gemm_vbatched', '--parallel', '12'], stdout=log, stderr=subprocess.STDOUT, check=True)
    for variant in ['baseline', 'candidate']:
        env = {**os.environ, 'LD_LIBRARY_PATH': f'{root}/install-{variant}/lib:' + original_library_path}
        for ranks in [1, 2]:
            with (regression / f'{variant}-mpi{ranks}.log').open('wb') as log:
                subprocess.run(['mpirun', '-np', str(ranks), '--bind-to', 'none',
                                str(root / 'build-candidate/tests/test_gemm_vbatched')],
                               env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
    (regression / 'PASS').touch()

