import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

root = Path(os.environ['VALIDATION_ROOT'])
out = root / 'results/integration-build'
out.mkdir(parents=True, exist_ok=True)
deps = root.parent / 'exx-device-20261018-3'
steps = []


def run(name, command, env=None):
    command = list(map(str, command))
    print('START', name, flush=True)
    (out / (name + '.command')).write_text(shlex.join(command) + '\n')
    with (out / (name + '.log')).open('wb') as log:
        p = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    steps.append({'step': name, 'exit_code': p.returncode})
    (out / 'steps.json').write_text(json.dumps(steps, indent=2) + '\n')
    print('END', name, p.returncode, flush=True)
    assert p.returncode == 0, name


build = root / 'build-libri-tests'
run('libri-configure', ['cmake', '-S', root / 'control', '-B', build,
    '-DCMAKE_BUILD_TYPE=Debug', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
    f'-DRUN_ROOT={root}', f'-DCMAKE_PREFIX_PATH={root}/install-baseline',
    f'-DLIBCOMM_ROOT={deps}/build/hse-deps/libcomm',
    f'-DCEREAL_ROOT={deps}/build/hse-deps/cereal-install',
    '-DTEST_BLAS=/opt/devtools/saiblas/2603-gnu-avx2/lib/libopenblas.so'])
run('libri-build', ['cmake', '--build', build, '--parallel', '4'])
for variant in ['baseline', 'candidate']:
    env = {**os.environ, 'LD_LIBRARY_PATH': f'{root}/install-{variant}/lib:' + os.environ['LD_LIBRARY_PATH']}
    for threads in ['1', '4']:
        env['OMP_NUM_THREADS'] = threads
        for scalar in ['real_float', 'real_double', 'complex_float', 'complex_double']:
            run(f'libri-{variant}-{scalar}-omp{threads}',
                ['mpirun', '-np', '1', '--map-by', os.environ['MAP_OPT'], build / scalar], env)

build = root / 'abacus-build'
run('abacus-configure', ['cmake', '-S', root / 'abacus-source', '-B', build,
    '-G', 'Unix Makefiles', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
    '-DENABLE_LIBXC=ON', '-DENABLE_LIBRI=ON', '-DENABLE_LIBRI_GPU=ON',
    '-DENABLE_ELPA=OFF', '-DENABLE_NCCL_PARALLEL_DEVICE=OFF', '-DBUILD_TESTING=OFF',
    '-DGIT_SUBMODULE=OFF', '-DCMAKE_CUDA_ARCHITECTURES=70',
    '-DUSE_CUDA=ON', '-DUSE_CUDA_MPI=ON', '-DENABLE_CUSOLVERMP=ON', '-DENABLE_CUBLASMP=ON',
    f'-DLIBRI_DIR={root}/libri', f'-DLIBCOMM_DIR={deps}/build/hse-deps/libcomm',
    f'-Dcereal_DIR={deps}/build/hse-deps/cereal-install/lib/cmake/cereal',
    f'-DDDLA_ROOT={root}/install-baseline', f'-DDDLA_INCLUDE_DIR={root}/install-baseline/include'])
run('abacus-build', ['cmake', '--build', build, '--target', 'abacus_std_gpu', '--parallel', '12'])
binary = build / 'abacus_std_gpu'
run('abacus-version', [binary, '--version'])
(out / 'abacus-sha256.txt').write_text(hashlib.sha256(binary.read_bytes()).hexdigest() + '\n')
(out / 'PASS').touch()
