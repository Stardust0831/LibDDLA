#!/usr/bin/env python3
"""Bind each rank inside the scheduler cpuset before loading OpenMP/BLAS."""
import json
import os
from pathlib import Path
import sys

mapping = json.loads(Path(os.environ['BENCH_MAPPING_FILE']).read_text())
rank = int(os.environ['OMPI_COMM_WORLD_RANK'])
cpus = mapping['rank_cpus'][rank]
assert set(cpus) <= set(mapping['allocated_cpus'])
assert set(cpus) <= os.sched_getaffinity(0)
os.sched_setaffinity(0, cpus)
os.environ['OMP_PLACES'] = ','.join('{' + str(cpu) + '}' for cpu in cpus)
binding = {
    'rank': rank, 'pid': os.getpid(),
    'cpu_affinity': sorted(os.sched_getaffinity(0)),
    'omp_places': os.environ['OMP_PLACES'],
    'omp_threads': int(os.environ['OMP_NUM_THREADS']),
    'blas_threads': int(os.environ['OPENBLAS_NUM_THREADS']),
    'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'),
}
assert len(cpus) == binding['omp_threads']
Path(f'binding-{rank}.json').write_text(json.dumps(binding, indent=2) + '\n')
os.execvpe(sys.argv[1], sys.argv[1:], os.environ)
